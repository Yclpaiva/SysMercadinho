from django.contrib import admin
from .models import Categoria,Produtos
# Register your models here.

admin.site.register(Categoria)
admin.site.register(Produtos)
